import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';

class HealingProgressScreen extends StatelessWidget {
  const HealingProgressScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return  SafeArea(
        child: Scaffold(
      body: Column(
        children: [
          BarChart(
            BarChartData(
                ),
            swapAnimationDuration: Duration(milliseconds: 150), // Optional
            swapAnimationCurve: Curves.linear, // Optional
          )
        ],
      ),
    ));
  }
}
