// ignore_for_file: avoid_print, file_names

import 'dart:async';

import 'package:flutter/material.dart';

import 'package:get/get.dart';



class LoginController extends GetxController {
  final TextEditingController ctrUserName = TextEditingController();
  final TextEditingController ctrPassword = TextEditingController();
  final FocusNode focusNodeUserName = FocusNode();
  final FocusNode focusNodePassword = FocusNode();

  RxBool isEmpty = true.obs;

  bool popScope() {
    return false;
  }
// onPressForgotPassword(){
// Get.to(()=>ForgotPasswordScreen());
// }

  // Future<void> onPressLogin() async {
  //   try {
  //     if (ctrUserName.text.isEmpty) {
  //       ShowDialog('Please Enter the Username');
  //     } else if (ctrPassword.text.isEmpty) {
  //       ShowDialog('Please Enter the Password');
  //     } else {
  //       ShowLoading(message: 'Checking User..');

  //       await API_LoginVerify(false, ctrUserName.text, ctrPassword.text,
  //           (success,dynamic data, message) async {
  //         if (success) {
  //           //Save Member Details Object
  //           Constants.objMember = data;
  //           await SetSharedPref(
  //               1, Constants.KEY_MEMBERCODE, data['MembershipNo']);
  //           await SetSharedPref(2, Constants.KEY_MEMBERID, data['Id']);
  //           await SetSharedPref(
  //               1, Constants.KEY_MEMBERLOGINUUID, data['MemberLoginUUID']);

  //           HideLoading();
  //           Get.to(DashboardScreen());

  //         } else {
  //           print("Failed to obtain token.");
  //           HideLoading();
  //           ShowDialog(message);
  //         }
  //       });
  //       ctrPassword.clear();
  //       ctrUserName.clear();
  //     }
  //   } catch (e) {
  //     print(
  //         '======== EXCEPTION =====> \n [LoginController] - onPressLogin() $e ');
  //   }
  // }
}
