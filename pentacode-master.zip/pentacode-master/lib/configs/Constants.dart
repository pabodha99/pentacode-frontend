// ignore_for_file: non_constant_identifier_names, file_names

class Constants{

  static String KEY_THEME = 'theme';
  static String KEY_ACCESSTOKEN = 'KEY_ACCESSTOKEN';
  static String KEY_MENU_ACCESSTOKEN = 'KEY_MENU_ACCESSTOKEN';
  static String KEY_REFRESHTOKEN = 'KEY_REFRESHTOKEN';
  static String KEY_MENU_REFRESHTOKEN = 'KEY_MENU_REFRESHTOKEN';
  static String KEY_MEMBERID = 'KEY_MEMBERID';
  static String KEY_MEMBERCODE = 'KEY_MEMBERCODE';
  static String KEY_MEMBERLOGINUUID = 'KEY_MEMBERLOGINUUID';
  static String KEY_AUTOLOGIN = 'KEY_AUTOLOGIN';
  static String KEY_DEFAULT_PROPERTY_ID = 'KEY_DEFAULT_PROPERTY_ID'; 
  static String KEY_DEFAULT_OUTLET = 'KEY_DEFAULT_OUTLET';
  static String KEY_DEFAULT_WSTATION = 'KEY_DEFAULT_WSTATION';


  static var objMember = {};

}