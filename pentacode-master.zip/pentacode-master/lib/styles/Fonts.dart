// ignore_for_file: non_constant_identifier_names, file_names

class Fonts {
  static String POPPINS_THIN = "Poppins-Thin";
  static String POPPINS_LIGHT = "Poppins-Light";
  static String POPPINS_REGULAR = "Poppins-Regular";
  static String POPPINS_MEDIUM = "Poppins-Medium";
  static String POPPINS_SEMIBOLD = "Poppins-SemiBold";
  static String POPPINS_BOLD = "Poppins-Bold";
  static String POPPINS_EXTRABOLD = "Poppins-ExtraBold";
}
