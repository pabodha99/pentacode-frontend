package com.example.pentacode

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
